=== Spin360 360° 3D Model Viewer using image sequences ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: 
Tags: 360 deg viewer, 3d viewer, 3D model viewer, 3d model display, 3D Model Viewer WordPress
Requires at least: 4.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin to add 360 rotation support and 3d view in wordpress using shortcodes
Responsive Web Design
3D model Rotation, 360 deg view.

== Description ==

An experimental plugin to add 360 deg and 3d view in wordpress using shortcodes
Responsive Web Design
Displays 3D model on wordPress page, post, or custom page
3D model Rotation enabled
Based on a sequence of images to display the product

Plugin Features

* 3D model Display
* 360 deg view enabled
* ShortCodes System
* Very Lightweight

Live Preview: 

== Installation ==

1. To Do


Shortcode Parameters:

* To Do


== Frequently asked questions ==
Display 3D model on wordPress page, post, or custom page, 3D model Rotation, 360 view enabled.

== Upgrade Notice ==

= 1.0 =
Basic version, still under development

== Screenshots ==

1. To Do


== Changelog ==

= 1.0 =
* Initial release